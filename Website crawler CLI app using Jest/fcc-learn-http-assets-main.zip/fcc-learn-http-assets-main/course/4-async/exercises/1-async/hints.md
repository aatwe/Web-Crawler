## Hints

### Milliseconds

`setTimout's` time duration is calculated in milliseconds.

1 second = 1000 milliseconds.

### Total wait time

The time required to complete a round of crafting is 2 seconds, so make sure none of the wait times are greater than `2000`.
