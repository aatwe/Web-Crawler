## Hint

Don't use the `itemURL` directly in the call to `fetch`. Pass it in as a parameter to `getData`.
