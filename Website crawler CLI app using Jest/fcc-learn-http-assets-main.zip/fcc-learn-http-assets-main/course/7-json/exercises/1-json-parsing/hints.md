# Hint

Don't forget `.json()` returns a promise! You will need to `await` it to get the actual data.
