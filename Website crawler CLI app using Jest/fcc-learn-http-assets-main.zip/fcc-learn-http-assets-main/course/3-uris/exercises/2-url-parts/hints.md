## Hints

In JavaScript you can print dynamic values using the following format:

```js
const age = 5
console.log(`You are ${age} years old`)
// You are 5 years old
```

Notice the backticks being used, they aren't signle quotes!
